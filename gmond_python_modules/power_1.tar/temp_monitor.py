'''
Created on Sep 26, 2012

@author: bond
'''


from powermonitor.module import *





def temp_handler(name):
    
    try:
        PLUGIN_NAME = 'temp'
        NODE_ID = name
        CpowerMonitor = Monitor(PLUGIN_NAME,NODE_ID)
        print CpowerMonitor.getTemperatureFormDb()
    except:
        return 0


def create_desc(skel, prop):
    d = skel.copy()
    for k,v in prop.iteritems():
        d[k] = v
    return d

def metric_init(params):
    global descriptors, metric_map, Desc_Skel

    descriptors = []
    
    Desc_Skel = {
          'name': 'XXX',
          'call_back': temp_handler,
          'time_max': 90,
          'value_type': 'uint',
          'units': 'C',
          'slope': 'both',
          'format': '%.4f',
          'description': 'bond of host',
          'groups': 'temp'
    }
    descriptors.append(create_desc(Desc_Skel, {
        "name" : "203",
    }))
   

    return descriptors

def metric_cleanup():
    '''Clean up the metric module.'''
    pass

#This code is for debugging and unit testing
if __name__ == '__main__':
    metric_init({})
    for d in descriptors:
        v = d['call_back'](d['name'])
        print 'value for %s is %u' % (d['name'],  v)