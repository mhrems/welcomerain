'''
Created on Sep 26, 2012

@author: bond
'''




def power_handler(name):
    return 0


def metric_init(params):
    global descriptors, acpi_file

  

    d1 = {
          'name': 'rack_power',
          'call_back': power_handler,
          'time_max': 90,
          'value_type': 'uint',
          'units': 'C',
          'slope': 'both',
          'format': '%f',
          'description': 'bond of host',
          'groups': 'power'
    }

    descriptors = [d1]

    return descriptors

def metric_cleanup():
    '''Clean up the metric module.'''
    pass

#This code is for debugging and unit testing
if __name__ == '__main__':
    metric_init({})
    for d in descriptors:
        v = d['call_back'](d['name'])
        print 'value for %s is %u' % (d['name'],  v)